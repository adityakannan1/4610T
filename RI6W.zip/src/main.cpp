/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       adityakannan                                              */
/*    Created:      Thu Jun 13 2024                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// rightMotors          motor_group   1, 2            
// leftMotors           motor_group   3, 4            
// arm                  motor         5               
// claw                 motor         6               
// Controller1          controller                    
// MogoMech             digital_out   A               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;
bool clawOpen;
bool clamped;


void clawOC(){
  if (clawOpen){
    claw.spinToPosition(0,degrees);
  } else{
    claw.spinToPosition(15,degrees);
  }
  clawOpen=!clawOpen;
}




void preAuton(void){
  vexcodeInit();
  clawOpen=false;
  clamped=false;
}

void auton(void){

}

void driveCode() {
 leftMotors.spin(forward, (Controller1.Axis3.value() + (Controller1.Axis1.value())), percent);
 rightMotors.spin(forward, (Controller1.Axis3.value() - (Controller1.Axis1.value())), percent);
 }

void mogoMechClamp(bool clamp){
  if (clamp){
    MogoMech.set(true);
  } else{
    MogoMech.set(false);
  }
}
void mogoMech(){
  if (clamped){
    mogoMechClamp(true);
  } else{
    mogoMechClamp(true);
  }
  clamped=!clamped;
}

void usercontrol(void){
  Controller1.ButtonR2.pressed(clawOC);
  while (1){
    thread driveThread(driveCode);

    if (Controller1.ButtonL2.pressing()){
      arm.spin(forward);
    } else if (Controller1.ButtonL1.pressing()){
      arm.spin(reverse);
    } else{
      arm.setStopping(hold);
      arm.stop();
    }
    Controller1.ButtonR1.pressed(mogoMech);

    wait(20,msec);
  }
}

int main() {
  // Set up callbacks for autonomous and driver control periods.
 Competition.drivercontrol(usercontrol);
 //auton callback set in pre_auton
 Competition.autonomous(auton);
 // Run the pre-autonomous function.
 preAuton();
 // Prevent main from exiting with an infinite loop.
 while (true) {
   wait(100, msec);
 }

  
}
